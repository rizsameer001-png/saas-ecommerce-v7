import { useEffect, useState } from 'react'
import { adminApi } from '../../api/services'
import { StatusBadge } from '../../components/ui/index'
import { format } from 'date-fns'
import toast from 'react-hot-toast'

export default function AdminStores() {
  const [stores, setStores] = useState([])
  const [loading, setLoading] = useState(true)

  const fetch = () => adminApi.getStores().then(r => setStores(r.data.data)).catch(console.error).finally(() => setLoading(false))
  useEffect(() => { fetch() }, [])

  const updateStatus = async (id, status) => {
    try { await adminApi.updateStoreStatus(id, status); toast.success('Store updated'); fetch() }
    catch { toast.error('Failed to update') }
  }
  const updatePlan = async (id, plan) => {
    try { await adminApi.updateStorePlan(id, plan); toast.success('Plan updated'); fetch() }
    catch { toast.error('Failed to update plan') }
  }

  return (
    <div className="space-y-5">
      <div><h1 className="text-2xl font-display font-bold text-white">Stores</h1><p className="text-gray-400 text-sm mt-1">Manage all vendor stores</p></div>
      <div className="bg-gray-800 rounded-2xl border border-gray-700 overflow-hidden">
        <table className="w-full text-sm">
          <thead><tr className="border-b border-gray-700">{['Store','Owner','Plan','Revenue','Status','Actions'].map(h => <th key={h} className="px-5 py-3 text-left text-xs font-semibold text-gray-400 uppercase">{h}</th>)}</tr></thead>
          <tbody>
            {loading ? Array(6).fill(0).map((_, i) => <tr key={i}>{Array(6).fill(0).map((_, j) => <td key={j} className="px-5 py-3"><div className="skeleton h-4 w-20 bg-gray-700" /></td>)}</tr>)
              : stores.map(s => (
                <tr key={s._id} className="border-t border-gray-700 hover:bg-gray-700/40 transition-colors">
                  <td className="px-5 py-3"><p className="text-white font-medium">{s.name}</p><p className="text-gray-400 text-xs">/{s.slug}</p></td>
                  <td className="px-5 py-3 text-gray-300">{s.owner?.name}<br/><span className="text-xs text-gray-500">{s.owner?.email}</span></td>
                  <td className="px-5 py-3">
                    <select value={s.plan} onChange={e => updatePlan(s._id, e.target.value)} className="bg-gray-700 text-white text-xs rounded-lg px-2 py-1 border border-gray-600">
                      {['free','basic','pro','enterprise'].map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </td>
                  <td className="px-5 py-3 text-white font-bold">${s.stats?.totalRevenue?.toFixed(2)}</td>
                  <td className="px-5 py-3"><StatusBadge status={s.status} /></td>
                  <td className="px-5 py-3">
                    <select value={s.status} onChange={e => updateStatus(s._id, e.target.value)} className="bg-gray-700 text-white text-xs rounded-lg px-2 py-1 border border-gray-600">
                      {['active','inactive','suspended'].map(v => <option key={v} value={v}>{v}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
