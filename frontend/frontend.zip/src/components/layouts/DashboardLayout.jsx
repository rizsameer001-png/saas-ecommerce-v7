import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useSelector, useDispatch } from 'react-redux'
import { logout } from '../../store/authSlice'
import { useEffect, useState } from 'react'
import { fetchMyStore } from '../../store/storeSlice'
import {
  LayoutDashboard, Package, ShoppingCart, Tag, Percent,
  BarChart3, Settings, LogOut, Store, Users,
  ExternalLink, CreditCard, List, Image, AlertTriangle
} from 'lucide-react'
import api from '../../api/axios'
import SharedTopBar from './SharedTopBar'
import PanelFooter from './PanelFooter'

const NAV = [
  { to: '/dashboard',            label: 'Overview',    icon: LayoutDashboard, end: true },
  { to: '/dashboard/orders',     label: 'Orders',      icon: ShoppingCart },
  { to: '/dashboard/products',   label: 'Products',    icon: Package },
  { to: '/dashboard/categories', label: 'Categories',  icon: Tag },
  { to: '/dashboard/attributes', label: 'Attributes',  icon: List },
  { to: '/dashboard/coupons',    label: 'Coupons',     icon: Percent },
  { to: '/dashboard/banners',    label: 'Banners & Ads', icon: Image },
  { to: '/dashboard/customers',  label: 'Customers',   icon: Users },
  { to: '/dashboard/analytics',  label: 'Analytics',   icon: BarChart3 },
  { to: '/dashboard/billing',    label: 'Billing',     icon: CreditCard },
  { to: '/dashboard/settings',   label: 'Settings',    icon: Settings },
]

const PLAN_COLORS = { free:'bg-gray-100 text-gray-600', basic:'bg-blue-100 text-blue-700', pro:'bg-indigo-100 text-indigo-700', enterprise:'bg-amber-100 text-amber-700' }

export default function DashboardLayout() {
  const { user }    = useSelector(s => s.auth)
  const { myStore } = useSelector(s => s.store)
  const dispatch    = useDispatch()
  const navigate    = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [sub, setSub] = useState(null)

  useEffect(() => { dispatch(fetchMyStore()) }, [dispatch])
  useEffect(() => { api.get('/subscriptions').then(r => setSub(r.data.data)).catch(() => {}) }, [])

  // Handle logout from topbar
  useEffect(() => {
    const url = new URL(window.location.href)
    if (url.searchParams.get('logout')) { dispatch(logout()); navigate('/login') }
  }, [])

  const Sidebar = () => (
    <aside className="w-64 flex flex-col bg-white border-r border-gray-100 h-full">
      {/* Logo */}
      <div className="p-5 border-b border-gray-100">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
            <Store size={16} className="text-white" />
          </div>
          <div className="min-w-0">
            <p className="font-display font-bold text-gray-900 text-sm truncate">{myStore?.name || 'My Store'}</p>
            <p className="text-xs text-gray-400">Vendor Dashboard</p>
          </div>
        </div>
      </div>

      {/* Subscription status */}
      {sub && (
        <div className="px-4 py-3 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <span className={`text-xs font-bold px-2.5 py-1 rounded-full capitalize ${PLAN_COLORS[sub.plan] || PLAN_COLORS.free}`}>
              {sub.plan} Plan
            </span>
            {sub.daysUntilExpiry !== null && sub.daysUntilExpiry <= 7 && sub.daysUntilExpiry > 0 && (
              <div className="flex items-center gap-1 text-amber-600 text-xs font-semibold">
                <AlertTriangle size={11} /> {sub.daysUntilExpiry}d left
              </div>
            )}
          </div>
          {(sub.plan === 'free' || sub.status === 'expired') && (
            <button onClick={() => navigate('/dashboard/billing')} className="mt-1.5 text-xs text-indigo-600 font-semibold hover:underline">Upgrade Plan →</button>
          )}
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-0.5 overflow-y-auto scrollbar-thin">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end}
            className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}>
            <Icon size={16} />
            <span className="flex-1">{label}</span>
            {label === 'Billing' && sub?.status === 'expired' && <span className="w-2 h-2 bg-red-500 rounded-full" />}
          </NavLink>
        ))}
      </nav>

      {/* Bottom */}
      <div className="p-4 border-t border-gray-100 space-y-1.5">
        {myStore && (
          <a href={`/store/${myStore.slug}`} target="_blank" rel="noreferrer"
            className="sidebar-link text-indigo-600 hover:bg-indigo-50">
            <ExternalLink size={14} /> View My Store
          </a>
        )}
        <button onClick={() => { dispatch(logout()); navigate('/login') }}
          className="sidebar-link text-red-500 hover:bg-red-50 w-full">
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </aside>
  )

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex flex-shrink-0"><Sidebar /></div>

      {/* Mobile Sidebar */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-72 animate-slide-up"><Sidebar /></div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        <SharedTopBar onMenuToggle={() => setSidebarOpen(!sidebarOpen)} panelType="vendor" />
        <main className="flex-1 overflow-y-auto p-6 scrollbar-thin"><Outlet /></main>
        <PanelFooter panelType="vendor" />
      </div>
    </div>
  )
}
