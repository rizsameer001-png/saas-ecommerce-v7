import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { logout } from '../../store/authSlice'
import { LayoutDashboard, Store, Users, BarChart3, LogOut, ShieldCheck, Image } from 'lucide-react'
import SharedTopBar from './SharedTopBar'
import PanelFooter from './PanelFooter'
import { useState } from 'react'

const NAV = [
  { to: '/admin',           label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/stores',    label: 'Stores',    icon: Store },
  { to: '/admin/users',     label: 'Users',     icon: Users },
  { to: '/admin/banners',   label: 'Banners',   icon: Image },
  { to: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
]

export default function AdminLayout() {
  const dispatch  = useDispatch()
  const navigate  = useNavigate()
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const Sidebar = () => (
    <aside className="w-64 flex flex-col bg-gray-900 border-r border-gray-800 h-full">
      <div className="p-5 border-b border-gray-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center">
            <ShieldCheck size={16} className="text-white" />
          </div>
          <div>
            <p className="font-display font-bold text-white text-sm">SaaSStore</p>
            <p className="text-xs text-gray-400">Super Admin</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-0.5">
        {NAV.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${isActive ? 'bg-indigo-600 text-white' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`
            }>
            <Icon size={16} />{label}
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-gray-800">
        <button onClick={() => { dispatch(logout()); navigate('/login') }}
          className="w-full flex items-center gap-2 px-3 py-2.5 text-sm text-gray-400 hover:text-red-400 hover:bg-gray-800 rounded-xl transition-all">
          <LogOut size={14} /> Sign Out
        </button>
      </div>
    </aside>
  )

  return (
    <div className="flex h-screen bg-gray-950 overflow-hidden">
      <div className="hidden lg:flex flex-shrink-0"><Sidebar /></div>

      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/60" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-72"><Sidebar /></div>
        </div>
      )}

      <div className="flex-1 flex flex-col overflow-hidden">
        <SharedTopBar onMenuToggle={() => setSidebarOpen(!sidebarOpen)} panelType="admin" />
        <main className="flex-1 overflow-y-auto bg-gray-950 p-6 scrollbar-thin"><Outlet /></main>
        <PanelFooter panelType="admin" />
      </div>
    </div>
  )
}
